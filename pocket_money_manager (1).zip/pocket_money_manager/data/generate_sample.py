"""Regenerate the sample datasets: python data/generate_sample.py"""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from pmm.storage import Storage, clean_settings          # noqa: E402
from pmm.validation import validate_record               # noqa: E402

I, E = "income", "expense"
LONG = ("Group dinner after the hackathon with the whole team at the new restaurant near "
        "campus, split bill")[:100]
ROWS = [
    # date, type, category, amount, description
    ("2026-08-01", I, "Allowance", 5000, "Monthly pocket money from parents"),
    ("2026-08-02", E, "Food", 180, "Canteen lunch"),
    ("2026-08-03", E, "Transport", 60, "Metro card top-up"),
    ("2026-08-05", E, "Education", 450, "Notebooks and pens"),
    ("2026-08-07", E, "Entertainment", 350, "Movie with friends"),
    ("2026-08-09", E, "Food", 220, "Dinner at Paradise"),
    ("2026-08-12", I, "Gift", 1000, "Birthday gift from uncle"),
    ("2026-08-14", E, "Shopping", 1200, "T-shirt"),
    ("2026-08-16", E, "Food", 95, "Chai and snacks"),
    ("2026-08-18", E, "Transport", 120, "Auto fare"),
    ("2026-08-21", E, "Bills", 299, "Mobile recharge"),
    ("2026-08-25", E, "Health", 150, "Pharmacy"),
    ("2026-08-29", E, "Other", 0.01, "Boundary test: minimum amount"),
    ("2026-09-01", I, "Allowance", 5000, "Monthly pocket money from parents"),
    ("2026-09-02", E, "Food", 210, "Canteen lunch"),
    ("2026-09-04", E, "Education", 800, "Online course fee"),
    ("2026-09-06", E, "Transport", 80, "Bus pass"),
    ("2026-09-08", E, "Entertainment", 499, "Streaming subscription"),
    ("2026-09-10", I, "Salary", 1500, "Part-time tutoring"),
    ("2026-09-12", E, "Food", 260, "Pizza with roommates"),
    ("2026-09-12", E, "Food", 260, "Pizza with roommates"),          # same-day duplicate
    ("2026-09-15", E, "Shopping", 2200, "Headphones"),
    ("2026-09-19", E, "Bills", 299, "Mobile recharge"),
    ("2026-09-22", E, "Food", 140, "Breakfast and coffee"),
    ("2026-09-27", I, "Refund", 350, "Refund for returned book"),
    ("2026-10-01", I, "Allowance", 5000, "Monthly pocket money from parents"),
    ("2026-10-03", E, "Food", 190, "Canteen lunch"),
    ("2026-10-05", E, "Transport", 150, "Cab to railway station"),
    ("2026-10-07", E, "Entertainment", 600, "Concert ticket"),
    ("2026-10-10", I, "Scholarship", 25000, "Merit scholarship credit"),   # large income
    ("2026-10-11", E, "Education", 12000, "Semester fees"),               # large expense -> anomaly
    ("2026-10-14", E, "Food", 230, "Dinner with family"),
    ("2026-10-16", E, "Health", 400, "Dental check-up"),
    ("2026-10-20", E, "Bills", 299, "Mobile recharge"),
    ("2026-10-24", E, "Shopping", 900, "Backpack"),
    ("2026-10-28", E, "Food", 175, LONG),                                 # 100-char description
    ("2026-11-01", I, "Allowance", 5000, "Monthly pocket money from parents"),
    ("2026-11-03", E, "Food", 205, "Canteen lunch"),
    ("2026-11-05", E, "Transport", 90, "Metro card top-up"),
    ("2026-11-08", I, "Salary", 2000, "Part-time tutoring"),
    ("2026-11-10", E, "Entertainment", 380, "Bowling with friends"),
    ("2026-11-14", E, "Food", 310, "Birthday treat for a friend"),
    ("2026-11-18", E, "Shopping", 1500, "Sneakers"),
    ("2026-11-20", E, "Bills", 299, "Mobile recharge"),
    ("2026-11-22", E, "Food", 120, "Lunch (today's entry - date boundary)"),
]
# A few rows are written in messy case in the CSV to show normalisation on import.
MESSY = {"Dinner at Paradise": str.lower, "Auto fare": str.upper,
         "Sneakers": str.lower, "Bowling with friends": str.upper}

BROKEN = [
    ["date", "type", "category", "amount", "description"],
    ["2026-11-01", "income", "Allowance", "5000", "Valid row 1"],
    ["31-02-2026", "expense", "Food", "100", "Impossible date"],
    ["2026-11-02", "expense", "Food", "abc", "Text instead of amount"],
    ["2026-11-03", "expense", "Food", "-50", "Negative amount"],
    ["2026-11-04", "expense", "Food", "0", "Zero amount"],
    ["2026-11-05", "expense", "Food", "", "Blank amount"],
    ["2026-11-06", "expense", "Food", "80", ""],
    ["2026-11-07", "expense", "Spaceships", "80", "Unknown category"],
    ["2035-01-01", "expense", "Food", "80", "Future date"],
    ["2026-11-08", "transfer", "Food", "80", "Unknown type"],
    ["2026-11-09", "expense", "Food", "99999999", "Absurdly large amount"],
    ["2026-11-10", "expense", "Transport", "₹1,250.50", "Valid row 2 (currency symbol + comma)"],
    ["2026-11-11", "expense", "Food", "40", "Valid row 3", "extra-column"],
    ["2026-11-12", "expense", "Health", "75", "Valid row 4"],
]


def main():
    records = []
    for i, (d, t, c, a, desc) in enumerate(ROWS, start=1):
        rec = validate_record({"date": d, "type": t, "category": c, "amount": a,
                               "description": desc, "id": f"s{i:03d}"})
        records.append(rec)
    with (HERE / "sample_transactions.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["date", "type", "category", "amount", "description"])
        for r in records:
            w.writerow([r.date, r.type, MESSY.get(r.description, str)(r.category), f"{r.amount:.2f}", r.description])
    (HERE / "sample_transactions.json").write_text(
        json.dumps([r.to_dict() for r in records], indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8")
    with (HERE / "sample_broken.csv").open("w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows(BROKEN)
    # Seed the live store so the demo starts with realistic data.
    Storage(HERE / "transactions.json").save(records, clean_settings({}))
    print(f"Wrote {len(records)} sample records + broken CSV + seeded transactions.json")


if __name__ == "__main__":
    main()
