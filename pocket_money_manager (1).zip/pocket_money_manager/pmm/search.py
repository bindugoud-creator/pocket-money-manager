"""Keyword / category / date / amount filtering with sorting."""
from __future__ import annotations

from typing import Iterable, Optional

from .models import Transaction


def filter_transactions(txs: Iterable[Transaction], keyword: Optional[str] = None,
                        category: Optional[str] = None, tx_type: Optional[str] = None,
                        date_from: Optional[str] = None, date_to: Optional[str] = None,
                        min_amount: Optional[float] = None, max_amount: Optional[float] = None,
                        sort_by: str = "date", descending: bool = True) -> list[Transaction]:
    kw = keyword.strip().lower() if keyword else ""
    out = []
    for t in txs:
        if kw and kw not in f"{t.description} {t.category} {t.date} {t.id}".lower():
            continue
        if category and t.category.lower() != category.lower():
            continue
        if tx_type and t.type != tx_type:
            continue
        if date_from and t.date < date_from:
            continue
        if date_to and t.date > date_to:
            continue
        if min_amount is not None and t.amount < min_amount:
            continue
        if max_amount is not None and t.amount > max_amount:
            continue
        out.append(t)
    keys = {"date": lambda t: (t.date, t.id), "amount": lambda t: t.amount,
            "category": lambda t: (t.category.lower(), t.date)}
    out.sort(key=keys.get(sort_by, keys["date"]), reverse=descending)
    return out
