#!/usr/bin/env python3
"""Pocket Money Manager - terminal app entry point."""
import argparse
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

from pmm.ui_cli import run  # noqa: E402


def main() -> None:
    p = argparse.ArgumentParser(description="Pocket Money Manager")
    p.add_argument("--data", default=str(BASE / "data" / "transactions.json"),
                   help="path of the JSON data file")
    p.add_argument("--exports", default=str(BASE / "exports"),
                   help="folder for reports, charts and import logs")
    a = p.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    run(Path(a.data), Path(a.exports), BASE)


if __name__ == "__main__":
    main()
