"""JSON persistence with schema checks, corruption recovery, atomic writes."""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from .models import DEFAULT_SETTINGS, Transaction, new_id
from .validation import ValidationError, validate_record

SCHEMA_VERSION = 1


def clean_settings(raw) -> dict:
    """Merge with defaults, coercing bad values back to defaults."""
    out = {k: (dict(v) if isinstance(v, dict) else v) for k, v in DEFAULT_SETTINGS.items()}
    if not isinstance(raw, dict):
        return out
    cur = raw.get("currency")
    if isinstance(cur, str) and 0 < len(cur.strip()) <= 4:
        out["currency"] = cur.strip()
    for key in ("low_balance", "monthly_limit", "outlier_multiplier"):
        try:
            v = float(raw.get(key, out[key]))
            if v >= 0 and v == v and v != float("inf"):
                out[key] = v
        except (TypeError, ValueError):
            pass
    try:
        days = int(raw.get("inactivity_days", out["inactivity_days"]))
        if days >= 1:
            out["inactivity_days"] = days
    except (TypeError, ValueError):
        pass
    budgets = raw.get("category_budgets")
    if isinstance(budgets, dict):
        good = {}
        for k, v in budgets.items():
            try:
                if float(v) > 0:
                    good[str(k)] = float(v)
            except (TypeError, ValueError):
                continue
        out["category_budgets"] = good
    return out


class Storage:
    def __init__(self, path):
        self.path = Path(path)
        self.warnings: list[str] = []

    # ------------------------------------------------------------- load
    def load(self) -> tuple[list[Transaction], dict]:
        self.warnings = []
        try:
            text = self.path.read_text(encoding="utf-8")
            if not text.strip():
                raise ValueError("file is empty")
            data = json.loads(text)
        except FileNotFoundError:
            self.warnings.append("No data file found - created a fresh one.")
            return self._fresh()
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError, OSError) as exc:
            return self._recover(f"unreadable ({exc})")

        if isinstance(data, list):
            records, settings_raw = data, {}
        elif isinstance(data, dict) and isinstance(data.get("transactions"), list):
            records, settings_raw = data["transactions"], data.get("settings", {})
        else:
            return self._recover("in an unexpected format")

        txs, seen = [], set()
        for i, rec in enumerate(records, start=1):
            try:
                tx = validate_record(rec if isinstance(rec, dict) else {})
            except ValidationError as exc:
                self.warnings.append(f"Skipped stored record #{i}: {exc}")
                continue
            if tx.id in seen:
                tx.id = new_id()
            seen.add(tx.id)
            txs.append(tx)
        txs.sort(key=lambda t: (t.date, t.id))
        return txs, clean_settings(settings_raw)

    def _fresh(self):
        settings = clean_settings({})
        self.save([], settings)
        return [], settings

    def _recover(self, reason: str):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = self.path.with_name(f"{self.path.name}.corrupt-{stamp}")
        try:
            shutil.move(str(self.path), str(backup))
            self.warnings.append(f"Data file was {reason}. Backed up to {backup.name} "
                                 "and started a clean file.")
        except OSError:
            self.warnings.append(f"Data file was {reason}. Started a clean file.")
        return self._fresh()

    # ------------------------------------------------------------- save
    def save(self, txs: list[Transaction], settings: dict) -> None:
        payload = {"schema_version": SCHEMA_VERSION,
                   "settings": settings,
                   "transactions": [t.to_dict() for t in txs]}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=str(self.path.parent), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.path)       # atomic: never a half-written file
        except BaseException:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise
