"""Run with:  python -m unittest discover -s tests -v   (or: pytest)"""
import csv
import json
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pmm.alerts import get_alerts                                   # noqa: E402
from pmm.charts import generate_all                                 # noqa: E402
from pmm.engine import Ledger                                       # noqa: E402
from pmm.export import export_csv, export_markdown, export_text_audit  # noqa: E402
from pmm.importer import import_csv                                 # noqa: E402
from pmm.search import filter_transactions                          # noqa: E402
from pmm.storage import Storage                                     # noqa: E402
from pmm.summary import compute_summary, monthly_breakdown         # noqa: E402
from pmm.validation import (ValidationError, ask, Cancelled, parse_amount,  # noqa: E402
                            parse_category, parse_date, parse_description, parse_type)

TODAY = date(2026, 11, 22)


def make_ledger(tmp):
    return Ledger(Storage(Path(tmp) / "t.json"))


class TestValidation(unittest.TestCase):
    def test_amount_ok(self):
        self.assertEqual(parse_amount("12.505"), 12.51)
        self.assertEqual(parse_amount("₹1,250.50"), 1250.5)
        self.assertEqual(parse_amount("0.01"), 0.01)

    def test_amount_bad(self):
        for bad in ["", "   ", "abc", "-5", "0", "0.001", "nan", "inf", "1e12", None]:
            with self.assertRaises(ValidationError, msg=repr(bad)):
                parse_amount(bad)

    def test_date(self):
        self.assertEqual(parse_date("2026-11-22", TODAY), "2026-11-22")
        self.assertEqual(parse_date("22/11/2026", TODAY), "2026-11-22")
        for bad in ["", "31-02-2026", "2026-13-01", "2026-11-23", "1999-12-31", "hello"]:
            with self.assertRaises(ValidationError, msg=bad):
                parse_date(bad, TODAY)

    def test_type_category_description(self):
        self.assertEqual(parse_type("Spent"), "expense")
        self.assertEqual(parse_category("FOOD", "expense"), "Food")
        self.assertEqual(parse_category("2", "expense", allow_index=True), "Transport")
        with self.assertRaises(ValidationError):
            parse_category("Salary", "expense")            # income-only category
        with self.assertRaises(ValidationError):
            parse_description("   ")
        with self.assertRaises(ValidationError):
            parse_description("x" * 101)
        self.assertEqual(parse_description("a\tb\n c"), "a b c")

    def test_ask_loops_until_valid_and_cancels(self):
        answers = iter(["abc", "-1", "42"])
        errors = []
        self.assertEqual(ask("> ", parse_amount, input_fn=lambda _: next(answers),
                             on_error=errors.append), 42.0)
        self.assertEqual(len(errors), 2)
        with self.assertRaises(Cancelled):
            ask("> ", parse_amount, input_fn=lambda _: "q")


class TestStorageAndEngine(unittest.TestCase):
    def test_balance_and_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            led.add("income", "2026-11-01", "Allowance", 1000, "Pocket money")
            led.add("expense", "2026-11-02", "Food", 250.25, "Lunch")
            self.assertEqual(led.balance(), 749.75)
            again = make_ledger(tmp)                      # simulate restart
            self.assertEqual(again.balance(), 749.75)
            self.assertEqual(len(again.transactions), 2)

    def test_edit_delete(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            tx = led.add("expense", "2026-11-02", "Food", 100, "Lunch")
            led.edit(tx.id, amount=150)
            self.assertEqual(led.balance(), -150)
            with self.assertRaises(ValidationError):
                led.edit(tx.id, type="income")            # Food is not an income category
            led.delete(tx.id)
            self.assertEqual(led.transactions, [])
            with self.assertRaises(ValidationError):
                led.delete("nope")

    def test_invalid_add_rejected_and_not_saved(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            with self.assertRaises(ValidationError):
                led.add("expense", "2026-11-02", "Food", "abc", "x")
            self.assertEqual(len(make_ledger(tmp).transactions), 0)

    def test_missing_file_creates_template(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            self.assertTrue((Path(tmp) / "t.json").exists())
            self.assertTrue(led.warnings)

    def test_corrupt_and_empty_files_recovered(self):
        for content in ["{not json", "", "[1,2", '"just a string"', '{"transactions": 5}']:
            with tempfile.TemporaryDirectory() as tmp:
                p = Path(tmp) / "t.json"
                p.write_text(content, encoding="utf-8")
                led = Ledger(Storage(p))
                self.assertEqual(led.transactions, [])
                json.loads(p.read_text(encoding="utf-8"))           # clean file now valid
                if content:
                    self.assertTrue(list(Path(tmp).glob("t.json.corrupt-*")))

    def test_bad_records_skipped_good_kept(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "t.json"
            p.write_text(json.dumps({"transactions": [
                {"date": "2026-01-01", "type": "income", "category": "Gift", "amount": 5, "description": "ok"},
                {"date": "bad", "type": "income", "category": "Gift", "amount": 5, "description": "x"},
                "garbage"], "settings": {"low_balance": "oops", "currency": "$"}}), encoding="utf-8")
            led = Ledger(Storage(p))
            self.assertEqual(len(led.transactions), 1)
            self.assertEqual(len(led.warnings), 2)
            self.assertEqual(led.settings["currency"], "$")
            self.assertEqual(led.settings["low_balance"], 500.0)     # bad value -> default


class TestSearchSummaryAlerts(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.led = make_ledger(self.tmp.name)
        rows = [("income", "2026-09-01", "Allowance", 5000, "Pocket money"),
                ("expense", "2026-09-05", "Food", 200, "Pizza"),
                ("expense", "2026-10-05", "Food", 100, "Pizza again"),
                ("expense", "2026-10-06", "Transport", 50, "Bus"),
                ("expense", "2026-10-07", "Food", 120, "Lunch"),
                ("expense", "2026-10-08", "Food", 110, "Dinner"),
                ("expense", "2026-11-20", "Education", 9000, "Fees")]
        for r in rows:
            self.led.add(*r)

    def tearDown(self):
        self.tmp.cleanup()

    def test_search(self):
        t = self.led.transactions
        self.assertEqual(len(filter_transactions(t, keyword="pizza")), 2)
        self.assertEqual(len(filter_transactions(t, category="food", tx_type="expense")), 4)
        self.assertEqual(len(filter_transactions(t, date_from="2026-10-01", date_to="2026-10-31")), 4)
        self.assertEqual(len(filter_transactions(t, min_amount=1000)), 2)
        self.assertEqual(filter_transactions(t, sort_by="amount")[0].amount, 9000)

    def test_summary(self):
        s = compute_summary(self.led.transactions, self.led.settings, TODAY)
        self.assertEqual(s["income"], 5000)
        self.assertEqual(s["expense"], 9580)
        self.assertEqual(s["balance"], -4580)
        self.assertEqual(s["status"], "Critical")
        self.assertEqual(s["top_categories"][0][0], "Education")
        self.assertEqual([m["month"] for m in s["monthly"]], ["2026-09", "2026-10", "2026-11"])

    def test_empty_summary_does_not_crash(self):
        s = compute_summary([], self.led.settings, TODAY)
        self.assertEqual(s["balance"], 0)
        self.assertEqual(s["count"], 0)
        self.assertEqual(monthly_breakdown([]), [])

    def test_zero_spend_month_is_filled(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            led.add("income", "2026-01-05", "Gift", 10, "a")
            led.add("income", "2026-03-05", "Gift", 10, "b")
            self.assertEqual([m["month"] for m in monthly_breakdown(led.transactions)],
                             ["2026-01", "2026-02", "2026-03"])

    def test_alerts(self):
        msgs = " | ".join(a.message for a in get_alerts(self.led.transactions, self.led.settings, TODAY))
        self.assertIn("Negative balance", msgs)
        self.assertIn("Monthly limit breached", msgs)
        self.assertIn("Unusual expense", msgs)


class TestImportExportCharts(unittest.TestCase):
    def test_import_with_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            f = Path(tmp) / "in.csv"
            with f.open("w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(["Date", "Type", "Category", "Amount", "Description"])
                w.writerow(["2026-11-01", "income", "allowance", "100", "ok"])
                w.writerow(["2026-11-02", "expense", "Food", "abc", "bad amount"])
                w.writerow(["2026-11-03", "expense", "Food", "5", "ok too"])
                w.writerow(["2026-11-03", "expense", "Food", "5", "ok too"])      # repeat inside file: kept
            res = import_csv(f, led, error_dir=Path(tmp) / "logs")
            self.assertEqual((res.total, res.imported, res.duplicates, len(res.errors)), (4, 3, 0, 1))
            self.assertTrue(res.log_path and res.log_path.exists())
            self.assertIn("Row 3", res.log_path.read_text(encoding="utf-8"))
            again = import_csv(f, led, error_dir=Path(tmp) / "logs")      # re-import same file
            self.assertEqual((again.imported, again.duplicates), (0, 3))

    def test_import_bad_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            with self.assertRaises(ValidationError):
                import_csv(Path(tmp) / "missing.csv", led)
            f = Path(tmp) / "x.csv"
            f.write_text("a,b\n1,2\n", encoding="utf-8")
            with self.assertRaises(ValidationError):
                import_csv(f, led)                                  # missing columns
            f.write_text("", encoding="utf-8")
            with self.assertRaises(ValidationError):
                import_csv(f, led)                                  # empty file

    def test_sample_data_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            res = import_csv(ROOT / "data" / "sample_transactions.csv", led)
            self.assertEqual(res.imported, 45)
            self.assertEqual(len(res.errors), 0)
            bad = import_csv(ROOT / "data" / "sample_broken.csv", led, error_dir=Path(tmp) / "l")
            self.assertEqual(bad.imported, 3)
            self.assertEqual(len(bad.errors), 11)

    def test_exports_and_charts(self):
        with tempfile.TemporaryDirectory() as tmp:
            led = make_ledger(tmp)
            import_csv(ROOT / "data" / "sample_transactions.csv", led)
            led.add("expense", "2026-11-21", "Other", 5, "=HYPERLINK(\"evil\")")
            out = Path(tmp) / "out"
            md = export_markdown(led.transactions, led.settings, out)
            txt = export_text_audit(led.transactions, led.settings, out)
            cs = export_csv(led.transactions, out)
            self.assertIn("Key figures", md.read_text(encoding="utf-8"))
            self.assertIn("SHA-256", txt.read_text(encoding="utf-8"))
            self.assertIn("'=HYPERLINK", cs.read_text(encoding="utf-8-sig"))   # formula neutralised
            pngs = generate_all(led.transactions, out, led.settings)
            self.assertEqual(len(pngs), 3)
            self.assertTrue(all(p.stat().st_size > 5000 for p in pngs))


if __name__ == "__main__":
    unittest.main()
