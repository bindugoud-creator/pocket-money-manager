"""Multi-format export: Markdown report, plain-text audit log, CSV report."""
from __future__ import annotations

import csv
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Iterable

from .alerts import get_alerts
from .models import Transaction
from .summary import compute_summary, money, text_table

CSV_FIELDS = ["id", "date", "type", "category", "amount", "description"]


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _safe_cell(value: str) -> str:
    """Neutralise spreadsheet formula injection (=, +, -, @ at start)."""
    return "'" + value if value[:1] in ("=", "+", "-", "@") else value


def export_csv(txs: Iterable[Transaction], out_dir, name: str = "transactions") -> Path:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{name}_{_stamp()}.csv"
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(CSV_FIELDS)
        for t in sorted(txs, key=lambda t: (t.date, t.id)):
            w.writerow([t.id, t.date, t.type, t.category, f"{t.amount:.2f}",
                        _safe_cell(t.description)])
    return path


def export_markdown(txs: Iterable[Transaction], settings: dict, out_dir) -> Path:
    txs = sorted(txs, key=lambda t: (t.date, t.id))
    s, cur = compute_summary(txs, settings), settings["currency"]
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"report_{_stamp()}.md"
    L = ["# Pocket Money Manager - Summary Report", "",
         f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", "",
         f"**Status: {s['status']}** - {s['status_reason']}", "",
         "## Key figures", "", "| Metric | Value |", "|---|---:|",
         f"| Total income | {money(s['income'], cur)} |",
         f"| Total expense | {money(s['expense'], cur)} |",
         f"| Current balance | {money(s['balance'], cur)} |",
         f"| Transactions | {s['count']} |",
         f"| Average transaction | {money(s['avg_transaction'], cur)} |",
         f"| Average daily spend | {money(s['avg_daily_spend'], cur)} |",
         f"| Average monthly spend | {money(s['avg_monthly_spend'], cur)} |",
         f"| Savings rate | {s['savings_rate']}% |", "",
         f"**Trend:** {s['trend']}", "", "## Monthly trend", "",
         "| Month | Income | Expense | Net |", "|---|---:|---:|---:|"]
    L += [f"| {m['month']} | {money(m['income'], cur)} | {money(m['expense'], cur)} | "
          f"{money(m['net'], cur)} |" for m in s["monthly"]]
    L += ["", "## Top spending categories", "", "| Category | Spent |", "|---|---:|"]
    L += [f"| {c} | {money(v, cur)} |" for c, v in s["top_categories"]]
    L += ["", "## Warnings", ""]
    L += [f"- **{a.level.upper()}**: {a.message}" for a in get_alerts(txs, settings)]
    L += ["", "## All transactions", "", "| Date | Type | Category | Amount | Description |",
          "|---|---|---|---:|---|"]
    L += [f"| {t.date} | {t.type} | {t.category} | {money(t.signed_amount, cur)} | "
          f"{t.description.replace('|', '/')} |" for t in txs]
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
    return path


def export_text_audit(txs: Iterable[Transaction], settings: dict, out_dir) -> Path:
    txs = sorted(txs, key=lambda t: (t.date, t.id))
    s, cur = compute_summary(txs, settings), settings["currency"]
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"audit_log_{_stamp()}.txt"
    digest = hashlib.sha256(
        "\n".join(f"{t.id}|{t.date}|{t.type}|{t.category}|{t.amount:.2f}|{t.description}"
                  for t in txs).encode("utf-8")).hexdigest()
    rows, running = [], 0.0
    for t in txs:
        running += t.signed_amount
        rows.append([t.id, t.date, t.type, t.category, money(t.signed_amount, cur),
                     money(running, cur), t.description])
    body = text_table(["ID", "Date", "Type", "Category", "Amount", "Balance", "Description"],
                      rows, right=(4, 5), max_width=45)
    text = (f"POCKET MONEY MANAGER - AUDIT LOG\nGenerated : {datetime.now():%Y-%m-%d %H:%M:%S}\n"
            f"Records   : {s['count']}\nIncome    : {money(s['income'], cur)}\n"
            f"Expense   : {money(s['expense'], cur)}\nBalance   : {money(s['balance'], cur)}\n"
            f"Status    : {s['status']}\nSHA-256   : {digest}\n\n{body}\n")
    path.write_text(text, encoding="utf-8")
    return path
