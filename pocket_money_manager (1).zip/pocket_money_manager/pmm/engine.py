"""Core business logic: log money received/spent, edit, delete, balances."""
from __future__ import annotations

from typing import Iterable, Optional

from .models import EXPENSE, INCOME, Transaction
from .storage import Storage, clean_settings
from .validation import (ValidationError, parse_amount, parse_category,
                         parse_date, parse_description, parse_type, validate_record)


class Ledger:
    def __init__(self, storage: Storage):
        self.storage = storage
        self.transactions, self.settings = storage.load()
        self.warnings = list(storage.warnings)

    # ---------------------------------------------------------- persistence
    def _commit(self) -> None:
        self.transactions.sort(key=lambda t: (t.date, t.id))
        self.storage.save(self.transactions, self.settings)

    # ------------------------------------------------------------- queries
    def get(self, tx_id: str) -> Optional[Transaction]:
        tx_id = str(tx_id).strip().lower()
        return next((t for t in self.transactions if t.id.lower() == tx_id), None)

    def totals(self) -> tuple[float, float]:
        inc = sum(t.amount for t in self.transactions if t.type == INCOME)
        exp = sum(t.amount for t in self.transactions if t.type == EXPENSE)
        return round(inc, 2), round(exp, 2)

    def balance(self) -> float:
        inc, exp = self.totals()
        return round(inc - exp, 2)

    def would_overdraw(self, amount: float) -> bool:
        return amount > self.balance()

    # ----------------------------------------------------------- mutations
    def add(self, tx_type, date, category, amount, description) -> Transaction:
        tx = validate_record({"type": tx_type, "date": date, "category": category,
                              "amount": amount, "description": description})
        self.transactions.append(tx)
        self._commit()
        return tx

    def add_many(self, txs: Iterable[Transaction]) -> int:
        txs = list(txs)
        self.transactions.extend(txs)
        if txs:
            self._commit()
        return len(txs)

    def edit(self, tx_id: str, **changes) -> Transaction:
        tx = self.get(tx_id)
        if tx is None:
            raise ValidationError(f"No transaction with id '{tx_id}'.")
        new_type = parse_type(changes["type"]) if changes.get("type") else tx.type
        # Re-validate everything so a type change cannot leave a bad category.
        updated = Transaction(
            id=tx.id,
            type=new_type,
            date=parse_date(changes.get("date", tx.date)),
            category=parse_category(changes.get("category", tx.category), new_type),
            amount=parse_amount(changes.get("amount", tx.amount)),
            description=parse_description(changes.get("description", tx.description)),
        )
        self.transactions[self.transactions.index(tx)] = updated
        self._commit()
        return updated

    def delete(self, tx_id: str) -> Transaction:
        tx = self.get(tx_id)
        if tx is None:
            raise ValidationError(f"No transaction with id '{tx_id}'.")
        self.transactions.remove(tx)
        self._commit()
        return tx

    def update_settings(self, **changes) -> dict:
        self.settings = clean_settings({**self.settings, **changes})
        self._commit()
        return self.settings
