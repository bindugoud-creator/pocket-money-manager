"""Matplotlib charts exported as PNG files."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable

from .models import EXPENSE, Transaction
from .summary import balance_history, category_totals, monthly_breakdown

PALETTE = {"income": "#10b981", "expense": "#ef4444", "balance": "#6366f1", "grid": "#e5e7eb"}


class ChartUnavailable(RuntimeError):
    """Matplotlib is not installed."""


def _plt():
    try:
        import matplotlib
        matplotlib.use("Agg")           # headless-safe backend
        import matplotlib.pyplot as plt
        return plt
    except ImportError as exc:
        raise ChartUnavailable("Matplotlib is not installed. Run: pip install matplotlib") from exc


def _style(ax, title, ylabel=None):
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    if ylabel:
        ax.set_ylabel(ylabel)
    ax.grid(axis="y", color=PALETTE["grid"], linewidth=0.8)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def balance_trend(txs: Iterable[Transaction], out: Path, settings: dict) -> Path:
    plt = _plt()
    hist = balance_history(txs)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    xs = [datetime.strptime(d, "%Y-%m-%d") for d, _ in hist]
    ys = [b for _, b in hist]
    ax.plot(xs, ys, color=PALETTE["balance"], linewidth=2.2, marker="o", markersize=3)
    ax.fill_between(xs, ys, alpha=0.12, color=PALETTE["balance"])
    ax.axhline(settings["low_balance"], color=PALETTE["expense"], linestyle="--",
               linewidth=1, label=f"Low-balance threshold ({settings['low_balance']:,.0f})")
    ax.legend(frameon=False)
    _style(ax, "Balance Trend", f"Balance ({settings['currency']})")
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return out


def monthly_bars(txs: Iterable[Transaction], out: Path, settings: dict) -> Path:
    plt = _plt()
    months = monthly_breakdown(txs)
    labels = [m["month"] for m in months]
    x = range(len(months))
    w = 0.38
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.bar([i - w / 2 for i in x], [m["income"] for m in months], w,
           label="Income", color=PALETTE["income"])
    ax.bar([i + w / 2 for i in x], [m["expense"] for m in months], w,
           label="Expense", color=PALETTE["expense"])
    ax.plot(list(x), [m["net"] for m in months], color=PALETTE["balance"], marker="o",
            linewidth=2, label="Net")
    ax.set_xticks(list(x))
    ax.set_xticklabels(labels)
    ax.legend(frameon=False)
    _style(ax, "Monthly Income vs Expense", f"Amount ({settings['currency']})")
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return out


def category_breakdown(txs: Iterable[Transaction], out: Path, settings: dict) -> Path:
    plt = _plt()
    cats = category_totals(txs, EXPENSE)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.8))
    if cats:
        names, vals = list(cats), list(cats.values())
        total = sum(vals)
        ax1.pie(vals, startangle=90, pctdistance=0.78,
                autopct=lambda p: f"{p:.0f}%" if p >= 4 else "",
                wedgeprops={"width": 0.45, "edgecolor": "white"})
        ax1.legend(names, loc="center left", bbox_to_anchor=(0.98, 0.5), frameon=False)
        ax1.text(0, 0, f"Total\n{settings['currency']}{total:,.0f}", ha="center", va="center",
                 fontsize=11, fontweight="bold")
        ax1.set_title("Spending Share by Category", fontsize=13, fontweight="bold")
        ax2.barh(names[::-1], vals[::-1], color=PALETTE["expense"])
        _style(ax2, "Spending by Category")
        ax2.grid(axis="x", color=PALETTE["grid"])
        ax2.grid(axis="y", visible=False)
        ax2.set_xlabel(f"Amount ({settings['currency']})")
    else:
        ax1.text(0.5, 0.5, "No expenses yet", ha="center")
        ax1.axis("off")
        ax2.axis("off")
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return out


def generate_all(txs: Iterable[Transaction], out_dir, settings: dict) -> list[Path]:
    txs = list(txs)
    if not txs:
        raise ValueError("No transactions to chart yet.")
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return [
        balance_trend(txs, out_dir / f"balance_trend_{stamp}.png", settings),
        monthly_bars(txs, out_dir / f"monthly_income_vs_expense_{stamp}.png", settings),
        category_breakdown(txs, out_dir / f"category_breakdown_{stamp}.png", settings),
    ]
