"""Executive summary metrics + plain-text table rendering."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from typing import Iterable, Optional, Sequence

from .models import EXPENSE, INCOME, Transaction


def money(value: float, currency: str = "₹") -> str:
    sign = "-" if value < 0 else ""
    return f"{sign}{currency}{abs(value):,.2f}"


# ---------------------------------------------------------------- tables
def table_lines(headers: Sequence[str], rows: Sequence[Sequence], right: Iterable[int] = (),
                max_width: int = 40) -> list[str]:
    """Fixed-width table. Returns [header, separator, *rows]; cells are truncated."""
    right = set(right)
    cells = [[str(c) if len(str(c)) <= max_width else str(c)[:max_width - 1] + "…" for c in r]
             for r in rows]
    widths = [max([len(h)] + [len(r[i]) for r in cells]) for i, h in enumerate(headers)]

    def fmt(vals):
        return " │ ".join(v.rjust(widths[i]) if i in right else v.ljust(widths[i])
                          for i, v in enumerate(vals))
    sep = "─┼─".join("─" * w for w in widths)
    return [fmt(headers), sep] + [fmt(r) for r in cells]


def text_table(headers, rows, right=(), max_width=40) -> str:
    return "\n".join(table_lines(headers, rows, right, max_width))


# ------------------------------------------------------------- aggregates
def _month_range(first: str, last: str) -> list[str]:
    y, m = int(first[:4]), int(first[5:7])
    ly, lm = int(last[:4]), int(last[5:7])
    out = []
    while (y, m) <= (ly, lm):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def monthly_breakdown(txs: Iterable[Transaction]) -> list[dict]:
    """Per-month income/expense/net, filling in months with no activity."""
    txs = list(txs)
    if not txs:
        return []
    inc, exp = defaultdict(float), defaultdict(float)
    for t in txs:
        (inc if t.type == INCOME else exp)[t.date[:7]] += t.amount
    months = _month_range(min(t.date for t in txs)[:7], max(t.date for t in txs)[:7])
    return [{"month": m, "income": round(inc[m], 2), "expense": round(exp[m], 2),
             "net": round(inc[m] - exp[m], 2)} for m in months]


def category_totals(txs: Iterable[Transaction], tx_type: str = EXPENSE) -> dict[str, float]:
    totals = defaultdict(float)
    for t in txs:
        if t.type == tx_type:
            totals[t.category] += t.amount
    return dict(sorted(((k, round(v, 2)) for k, v in totals.items()),
                       key=lambda kv: kv[1], reverse=True))


def balance_history(txs: Iterable[Transaction]) -> list[tuple[str, float]]:
    """Running balance at the end of each day that has activity."""
    running, by_day = 0.0, {}
    for t in sorted(txs, key=lambda t: (t.date, t.id)):
        running += t.signed_amount
        by_day[t.date] = round(running, 2)
    return list(by_day.items())


def financial_status(balance: float, income: float, expense: float,
                     month_expense: float, settings: dict) -> tuple[str, str]:
    if balance < 0:
        return "Critical", "Balance is negative - you have spent more than you received."
    if balance < settings["low_balance"]:
        return "Critical", "Balance is below your low-balance threshold."
    if settings["monthly_limit"] and month_expense > settings["monthly_limit"]:
        return "Caution", "This month's spending is above your monthly limit."
    if income > 0 and expense / income > 0.8:
        return "Caution", "You have spent over 80% of everything you received."
    return "Healthy", "Spending is under control and the balance is comfortable."


def compute_summary(txs: Iterable[Transaction], settings: dict,
                    today: Optional[date] = None) -> dict:
    txs = list(txs)
    today = today or date.today()
    income = round(sum(t.amount for t in txs if t.type == INCOME), 2)
    expense = round(sum(t.amount for t in txs if t.type == EXPENSE), 2)
    balance = round(income - expense, 2)
    incomes = [t for t in txs if t.type == INCOME]
    expenses = [t for t in txs if t.type == EXPENSE]

    if txs:
        first = datetime.strptime(min(t.date for t in txs), "%Y-%m-%d").date()
        last = datetime.strptime(max(t.date for t in txs), "%Y-%m-%d").date()
        span_days = max((last - first).days + 1, 1)
    else:
        span_days = 1

    months = monthly_breakdown(txs)
    this_month = today.strftime("%Y-%m")
    month_expense = next((m["expense"] for m in months if m["month"] == this_month), 0.0)
    status, status_reason = financial_status(balance, income, expense, month_expense, settings)

    trend = "Not enough data for a trend yet."
    if len(months) >= 2:
        prev, cur = months[-2]["expense"], months[-1]["expense"]
        if prev == 0 and cur == 0:
            trend = "No spending in the last two months."
        elif prev == 0:
            trend = f"Spending started this month ({money(cur, settings['currency'])})."
        else:
            pct = (cur - prev) / prev * 100
            word = "up" if pct > 0 else "down"
            trend = (f"Spending is {word} {abs(pct):.1f}% vs {months[-2]['month']} "
                     f"({money(prev, settings['currency'])} → {money(cur, settings['currency'])}).")

    return {
        "count": len(txs), "income": income, "expense": expense, "balance": balance,
        "avg_transaction": round(sum(t.amount for t in txs) / len(txs), 2) if txs else 0.0,
        "avg_income": round(income / len(incomes), 2) if incomes else 0.0,
        "avg_expense": round(expense / len(expenses), 2) if expenses else 0.0,
        "avg_daily_spend": round(expense / span_days, 2),
        "avg_monthly_spend": round(expense / len(months), 2) if months else 0.0,
        "savings_rate": round((income - expense) / income * 100, 1) if income else 0.0,
        "top_categories": list(category_totals(txs).items())[:5],
        "biggest_expense": max(expenses, key=lambda t: t.amount, default=None),
        "biggest_income": max(incomes, key=lambda t: t.amount, default=None),
        "monthly": months, "month_expense": month_expense,
        "status": status, "status_reason": status_reason, "trend": trend,
        "first_date": min((t.date for t in txs), default=None),
        "last_date": max((t.date for t in txs), default=None),
    }
