"""Data structures and domain constants."""
from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from datetime import date

INCOME = "income"
EXPENSE = "expense"
TYPES = (INCOME, EXPENSE)

INCOME_CATEGORIES = ["Allowance", "Salary", "Gift", "Scholarship", "Refund", "Other"]
EXPENSE_CATEGORIES = ["Food", "Transport", "Entertainment", "Education",
                      "Shopping", "Health", "Bills", "Other"]
CATEGORIES = {INCOME: INCOME_CATEGORIES, EXPENSE: EXPENSE_CATEGORIES}
ALL_CATEGORIES = sorted(set(INCOME_CATEGORIES) | set(EXPENSE_CATEGORIES))

MAX_AMOUNT = 1_000_000.00   # sanity ceiling for a single entry
MIN_AMOUNT = 0.01
MIN_DATE = date(2000, 1, 1)
MAX_DESC_LEN = 100

DEFAULT_SETTINGS = {
    "currency": "₹",
    "low_balance": 500.0,         # balance below this => critical
    "monthly_limit": 5000.0,      # monthly spending cap
    "outlier_multiplier": 3.0,    # expense > multiplier x avg expense => anomaly
    "inactivity_days": 7,         # remind if nothing logged for this long
    "category_budgets": {},       # e.g. {"Food": 1500}
}


def new_id() -> str:
    return uuid.uuid4().hex[:8]


@dataclass
class Transaction:
    date: str          # ISO yyyy-mm-dd
    type: str          # "income" | "expense"
    category: str
    amount: float      # always positive
    description: str
    id: str = field(default_factory=new_id)

    @property
    def signed_amount(self) -> float:
        return self.amount if self.type == INCOME else -self.amount

    def to_dict(self) -> dict:
        return asdict(self)
