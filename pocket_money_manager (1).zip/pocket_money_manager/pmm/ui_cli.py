"""Menu-driven terminal UI with ANSI styling."""
from __future__ import annotations

import os
import sys
from datetime import date
from pathlib import Path

from . import __version__
from .alerts import get_alerts
from .charts import ChartUnavailable, generate_all
from .engine import Ledger
from .export import export_csv, export_markdown, export_text_audit
from .importer import import_csv
from .models import CATEGORIES, EXPENSE, INCOME
from .search import filter_transactions
from .summary import compute_summary, money, table_lines
from .validation import (Cancelled, ValidationError, ask, ask_yes_no, optional,
                         parse_amount, parse_category, parse_date, parse_description,
                         parse_non_negative, parse_type)

PAGE_SIZE = 15


# ------------------------------------------------------------------ styling
class Style:
    enabled = sys.stdout.isatty() and "NO_COLOR" not in os.environ
    CODES = {"reset": "0", "bold": "1", "dim": "2", "red": "31", "green": "32",
             "yellow": "33", "blue": "34", "magenta": "35", "cyan": "36"}


def enable_ansi() -> None:
    if os.name == "nt":                 # activates ANSI processing in Windows consoles
        os.system("")


def paint(text: str, *styles: str) -> str:
    if not Style.enabled:
        return text
    start = "".join(f"\033[{Style.CODES[s]}m" for s in styles)
    return f"{start}{text}\033[0m"


def ok(msg):    print(paint(f"  ✔ {msg}", "green"))
def err(msg):   print(paint(f"  ✖ {msg}", "red"))
def info(msg):  print(paint(f"  ℹ {msg}", "cyan"))
def title(msg): print("\n" + paint(f"━━ {msg} ".ljust(64, "━"), "bold", "blue"))


def banner(ledger: Ledger) -> None:
    cur = ledger.settings["currency"]
    w = 58
    rows = ["", "P O C K E T   M O N E Y   M A N A G E R",
            "Track what you receive. Control what you spend.", f"v{__version__}", ""]
    print()
    print(paint("╔" + "═" * w + "╗", "bold", "cyan"))
    for r in rows:
        print(paint("║" + r.center(w) + "║", "bold", "cyan"))
    print(paint("╚" + "═" * w + "╝", "bold", "cyan"))
    bal = ledger.balance()
    col = "green" if bal >= ledger.settings["low_balance"] else "red"
    print(f"  Current balance: {paint(money(bal, cur), 'bold', col)}   "
          f"|  {len(ledger.transactions)} transactions on file")


MENU = [
    ("1", "Add income (money received)"), ("2", "Add expense (money spent)"),
    ("3", "View all transactions"), ("4", "Search / filter"),
    ("5", "Edit a transaction"), ("6", "Delete a transaction"),
    ("7", "Executive summary"), ("8", "Warnings & alerts"),
    ("9", "Generate charts (PNG)"), ("10", "Export reports"),
    ("11", "Bulk import from CSV"), ("12", "Settings"), ("0", "Exit"),
]


def show_menu() -> None:
    title("MAIN MENU")
    for key, label in MENU:
        print(f"  {paint(key.rjust(2), 'bold', 'yellow')}  {label}")


# ------------------------------------------------------------------- tables
def print_transactions(txs, cur, paginate=True) -> None:
    if not txs:
        info("No transactions to show.")
        return
    headers = ["#", "ID", "Date", "Type", "Category", "Amount", "Description"]
    rows = [[i, t.id, t.date, t.type, t.category, money(t.signed_amount, cur), t.description]
            for i, t in enumerate(txs, start=1)]
    lines = table_lines(headers, rows, right=(0, 5), max_width=34)
    head, body = lines[:2], lines[2:]
    pages = [body[i:i + PAGE_SIZE] for i in range(0, len(body), PAGE_SIZE)]
    n = 0
    while True:
        print("\n" + paint(head[0], "bold") + "\n" + head[1])
        for k, line in enumerate(pages[n]):
            t = txs[n * PAGE_SIZE + k]
            print(paint(line, "green" if t.type == INCOME else "red"))
        print(paint(f"  Page {n + 1}/{len(pages)} · {len(txs)} record(s)", "dim"))
        if not paginate or len(pages) == 1:
            break
        try:
            cmd = input("  [Enter] next · [p] previous · [q] stop: ").strip().lower()
        except EOFError:
            break
        if cmd == "q":
            break
        n = max(n - 1, 0) if cmd == "p" else (n + 1) % len(pages)


def pick_category(tx_type: str, label="Category") -> str:
    cats = CATEGORIES[tx_type]
    print("  " + "  ".join(f"{i}) {c}" for i, c in enumerate(cats, start=1)))
    return ask(f"  {label} (name or number): ",
               lambda r: parse_category(r, tx_type, allow_index=True))


# ------------------------------------------------------------------ actions
def show_alerts(ledger: Ledger, compact=False) -> None:
    alerts = get_alerts(ledger.transactions, ledger.settings)
    if compact:
        alerts = [a for a in alerts if a.level != "info"]
    if not alerts:
        ok("No warnings - everything looks fine.")
    icons = {"critical": ("🚨 CRITICAL", "red"), "warning": ("⚠️  WARNING ", "yellow"),
             "info": ("ℹ️  NOTICE  ", "cyan")}
    for a in alerts:
        label, colour = icons[a.level]
        print("  " + paint(f"{label} {a.message}", colour))


def action_add(ledger: Ledger, tx_type: str) -> None:
    title("ADD INCOME" if tx_type == INCOME else "ADD EXPENSE")
    print(paint("  (type 'q' at any prompt to cancel)", "dim"))
    try:
        today = date.today().isoformat()
        d = ask(f"  Date [YYYY-MM-DD, Enter = {today}]: ", parse_date, default=today)
        amount = ask("  Amount: ", parse_amount)
        category = pick_category(tx_type)
        desc = ask("  Description: ", parse_description)
        cur = ledger.settings["currency"]
        if tx_type == EXPENSE and ledger.would_overdraw(amount):
            err(f"This spends more than your balance ({money(ledger.balance(), cur)}).")
            if not ask_yes_no("  Record it anyway?"):
                info("Cancelled - nothing was saved.")
                return
        tx = ledger.add(tx_type, d, category, amount, desc)
    except Cancelled:
        info("Cancelled - nothing was saved.")
        return
    ok(f"Saved {tx.type} of {money(tx.amount, cur)} [{tx.id}]. "
       f"New balance: {money(ledger.balance(), cur)}")
    show_alerts(ledger, compact=True)


def action_view(ledger: Ledger) -> None:
    title("ALL TRANSACTIONS")
    txs = filter_transactions(ledger.transactions)
    print_transactions(txs, ledger.settings["currency"])


def action_search(ledger: Ledger) -> None:
    title("SEARCH / FILTER  (Enter = skip a filter)")
    cur = ledger.settings["currency"]
    try:
        kw = ask("  Keyword: ", lambda r: r.strip() or None)
        print("  Categories: " + ", ".join(sorted({c for v in CATEGORIES.values() for c in v})))
        cat = ask("  Category: ", optional(lambda r: parse_category(r)))
        typ = ask("  Type [income/expense]: ", optional(parse_type))
        dfrom = ask("  From date: ", optional(parse_date))
        dto = ask("  To date: ", optional(parse_date))
        mn = ask("  Min amount: ", optional(parse_amount))
        mx = ask("  Max amount: ", optional(parse_amount))
        sort = ask("  Sort by [date/amount/category, default date]: ",
                   lambda r: r.strip().lower() if r.strip().lower() in ("date", "amount", "category")
                   else (_ for _ in ()).throw(ValidationError("Choose date, amount or category.")),
                   default="date")
    except Cancelled:
        info("Search cancelled.")
        return
    if dfrom and dto and dfrom > dto:
        err("'From' date is after 'To' date.")
        return
    if mn is not None and mx is not None and mn > mx:
        err("Min amount is greater than max amount.")
        return
    res = filter_transactions(ledger.transactions, kw, cat, typ, dfrom, dto, mn, mx, sort)
    print_transactions(res, cur)
    if res:
        inc = sum(t.amount for t in res if t.type == INCOME)
        exp = sum(t.amount for t in res if t.type == EXPENSE)
        info(f"Matches: {len(res)} · income {money(inc, cur)} · expense {money(exp, cur)}")


def _pick_existing(ledger: Ledger):
    txs = filter_transactions(ledger.transactions)
    if not txs:
        info("There are no transactions yet.")
        return None
    print_transactions(txs[:10], ledger.settings["currency"], paginate=False)
    info("Showing the 10 most recent. Use Search to find older ones.")
    tx_id = ask("  Enter the transaction ID: ", lambda r: r.strip())
    tx = ledger.get(tx_id)
    if tx is None:
        err(f"No transaction with ID '{tx_id}'.")
    return tx


def action_edit(ledger: Ledger) -> None:
    title("EDIT TRANSACTION  (Enter = keep current value)")
    try:
        tx = _pick_existing(ledger)
        if tx is None:
            return
        d = ask(f"  Date [{tx.date}]: ", parse_date, default=tx.date)
        typ = ask(f"  Type [{tx.type}]: ", parse_type, default=tx.type)
        amount = ask(f"  Amount [{tx.amount:.2f}]: ", parse_amount, default=str(tx.amount))
        keep_cat = tx.category if tx.category in CATEGORIES[typ] else None
        print("  " + "  ".join(f"{i}) {c}" for i, c in enumerate(CATEGORIES[typ], start=1)))
        cat = ask(f"  Category [{keep_cat or 'choose'}]: ",
                  lambda r: parse_category(r, typ, allow_index=True), default=keep_cat)
        desc = ask(f"  Description [{tx.description}]: ", parse_description, default=tx.description)
        new = ledger.edit(tx.id, date=d, type=typ, amount=amount, category=cat, description=desc)
        ok(f"Updated [{new.id}].")
    except Cancelled:
        info("Edit cancelled.")


def action_delete(ledger: Ledger) -> None:
    title("DELETE TRANSACTION")
    try:
        tx = _pick_existing(ledger)
        if tx is None:
            return
        if ask_yes_no(f"  Delete {tx.date} {tx.category} {money(tx.amount, ledger.settings['currency'])}"
                      f" '{tx.description}'?"):
            ledger.delete(tx.id)
            ok("Deleted.")
        else:
            info("Kept - nothing deleted.")
    except Cancelled:
        info("Cancelled.")


def action_summary(ledger: Ledger) -> None:
    title("EXECUTIVE SUMMARY")
    cur = ledger.settings["currency"]
    s = compute_summary(ledger.transactions, ledger.settings)
    if not s["count"]:
        info("No data yet - add some transactions first.")
        return
    colour = {"Healthy": "green", "Caution": "yellow", "Critical": "red"}[s["status"]]
    print(f"\n  Status : {paint(' ' + s['status'].upper() + ' ', 'bold', colour)}  {s['status_reason']}")
    print(f"  Period : {s['first_date']} → {s['last_date']}  ({s['count']} transactions)\n")
    rows = [["Total income", money(s["income"], cur)], ["Total expense", money(s["expense"], cur)],
            ["Current balance", money(s["balance"], cur)], ["Savings rate", f"{s['savings_rate']}%"],
            ["Average transaction", money(s["avg_transaction"], cur)],
            ["Average income", money(s["avg_income"], cur)],
            ["Average expense", money(s["avg_expense"], cur)],
            ["Average daily spend", money(s["avg_daily_spend"], cur)],
            ["Average monthly spend", money(s["avg_monthly_spend"], cur)]]
    for ln in table_lines(["Metric", "Value"], rows, right=(1,)):
        print("  " + ln)
    be = s["biggest_expense"]
    if be:
        print(f"\n  Biggest expense : {money(be.amount, cur)} - {be.description} ({be.date})")
    bi = s["biggest_income"]
    if bi:
        print(f"  Biggest income  : {money(bi.amount, cur)} - {bi.description} ({bi.date})")
    print(f"  Trend           : {s['trend']}")

    print(paint("\n  Top spending categories", "bold"))
    top = s["top_categories"]
    peak = top[0][1] if top else 1
    for cat, val in top:
        bar = "█" * max(1, int(val / peak * 24))
        share = val / s["expense"] * 100 if s["expense"] else 0
        print(f"  {cat:<14}{money(val, cur):>14}  {share:5.1f}%  {paint(bar, 'magenta')}")

    print(paint("\n  Monthly trend", "bold"))
    rows = [[m["month"], money(m["income"], cur), money(m["expense"], cur), money(m["net"], cur)]
            for m in s["monthly"]]
    for ln in table_lines(["Month", "Income", "Expense", "Net"], rows, right=(1, 2, 3)):
        print("  " + ln)
    print(paint("\n  Warnings", "bold"))
    show_alerts(ledger)


def action_charts(ledger: Ledger, exports: Path) -> None:
    title("CHARTS")
    try:
        paths = generate_all(ledger.transactions, exports, ledger.settings)
    except ChartUnavailable as exc:
        err(str(exc))
        return
    except ValueError as exc:
        info(str(exc))
        return
    for p in paths:
        ok(f"Saved {p}")


def action_export(ledger: Ledger, exports: Path) -> None:
    title("EXPORT REPORTS")
    print("  1) Markdown report   2) Plain-text audit log   3) CSV report   4) All of them")
    try:
        choice = ask("  Choose [1-4]: ", lambda r: r.strip() if r.strip() in ("1", "2", "3", "4")
                     else (_ for _ in ()).throw(ValidationError("Enter 1, 2, 3 or 4.")))
    except Cancelled:
        return
    txs, st = ledger.transactions, ledger.settings
    if choice in ("1", "4"):
        ok(f"Saved {export_markdown(txs, st, exports)}")
    if choice in ("2", "4"):
        ok(f"Saved {export_text_audit(txs, st, exports)}")
    if choice in ("3", "4"):
        ok(f"Saved {export_csv(txs, exports)}")
    if choice == "4":
        try:
            for p in generate_all(txs, exports, st):
                ok(f"Saved {p}")
        except (ChartUnavailable, ValueError) as exc:
            info(f"Charts skipped: {exc}")


def action_import(ledger: Ledger, exports: Path, base: Path) -> None:
    title("BULK IMPORT FROM CSV")
    print("  Required columns: date, type, category, amount, description")
    default = str(base / "data" / "sample_transactions.csv")
    print(paint(f"  Try: data/sample_transactions.csv or data/sample_broken.csv", "dim"))
    try:
        raw = ask(f"  CSV path [Enter = {Path(default).name}]: ", lambda r: r.strip().strip('"'),
                  default=default)
        res = import_csv(raw, ledger, error_dir=exports)
    except Cancelled:
        info("Import cancelled.")
        return
    except ValidationError as exc:
        err(str(exc))
        return
    ok(f"Imported {res.imported} of {res.total} rows "
       f"({res.duplicates} duplicates skipped, {len(res.errors)} rejected).")
    for row_no, why, _ in res.errors[:10]:
        err(f"Row {row_no}: {why}")
    if len(res.errors) > 10:
        info(f"... and {len(res.errors) - 10} more in the log.")
    if res.log_path:
        info(f"Row-by-row log: {res.log_path}")


def action_settings(ledger: Ledger) -> None:
    title("SETTINGS  (Enter = keep current)")
    st = ledger.settings
    try:
        cur = ask(f"  Currency symbol [{st['currency']}]: ",
                  lambda r: r.strip() if 0 < len(r.strip()) <= 4
                  else (_ for _ in ()).throw(ValidationError("Use 1-4 characters.")),
                  default=st["currency"])
        low = ask(f"  Low-balance threshold [{st['low_balance']:.2f}]: ",
                  lambda r: parse_non_negative(r, "Threshold"), default=str(st["low_balance"]))
        lim = ask(f"  Monthly spending limit, 0 = off [{st['monthly_limit']:.2f}]: ",
                  lambda r: parse_non_negative(r, "Limit"), default=str(st["monthly_limit"]))
        mult = ask(f"  Anomaly multiplier [{st['outlier_multiplier']}]: ",
                   lambda r: parse_non_negative(r, "Multiplier"), default=str(st["outlier_multiplier"]))
        budgets = dict(st["category_budgets"])
        print(f"  Category budgets: {budgets or 'none'}")
        if ask_yes_no("  Add/change a category budget?"):
            cat = pick_category(EXPENSE, "Category")
            amt = ask("  Monthly budget (0 removes it): ", lambda r: parse_non_negative(r, "Budget"))
            budgets.pop(cat, None) if amt == 0 else budgets.__setitem__(cat, amt)
        ledger.update_settings(currency=cur, low_balance=low, monthly_limit=lim,
                               outlier_multiplier=mult, category_budgets=budgets)
        ok("Settings saved.")
    except Cancelled:
        info("Settings unchanged.")


# --------------------------------------------------------------- main loop
def run(data_path: Path, exports: Path, base: Path) -> None:
    enable_ansi()
    from .storage import Storage
    ledger = Ledger(Storage(data_path))
    banner(ledger)
    for w in ledger.warnings:
        print(paint(f"  ⚠ {w}", "yellow"))
    show_alerts(ledger, compact=True)

    actions = {
        "1": lambda: action_add(ledger, INCOME), "2": lambda: action_add(ledger, EXPENSE),
        "3": lambda: action_view(ledger), "4": lambda: action_search(ledger),
        "5": lambda: action_edit(ledger), "6": lambda: action_delete(ledger),
        "7": lambda: action_summary(ledger), "8": lambda: (title("WARNINGS & ALERTS"), show_alerts(ledger)),
        "9": lambda: action_charts(ledger, exports), "10": lambda: action_export(ledger, exports),
        "11": lambda: action_import(ledger, exports, base), "12": lambda: action_settings(ledger),
    }
    while True:
        show_menu()
        try:
            choice = input(paint("\n  Select an option ▸ ", "bold")).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if choice in ("0", "exit", "quit"):
            break
        action = actions.get(choice)
        if action is None:
            err("Invalid option - please enter a number from the menu.")
            continue
        try:
            action()
        except KeyboardInterrupt:
            info("Interrupted - back to menu.")
        except OSError as exc:
            err(f"File problem: {exc}")
        except Exception as exc:                        # last-resort guard: never crash the demo
            err(f"Unexpected error: {exc}")
        if choice in ("3", "4", "7", "8"):
            try:
                input(paint("\n  Press Enter to return to the menu...", "dim"))
            except (EOFError, KeyboardInterrupt):
                break
    print(paint("\n  Your data is saved. Goodbye! 👋\n", "green"))
