"""Pocket Money Manager - modern Streamlit dashboard.

Run:  streamlit run app_streamlit.py
Uses the exact same engine/storage as the terminal app (data/transactions.json).
"""
import tempfile
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from pmm.alerts import get_alerts
from pmm.charts import ChartUnavailable, generate_all
from pmm.engine import Ledger
from pmm.export import export_csv, export_markdown, export_text_audit
from pmm.importer import import_csv
from pmm.models import CATEGORIES, EXPENSE, INCOME
from pmm.search import filter_transactions
from pmm.storage import Storage
from pmm.summary import category_totals, compute_summary, monthly_breakdown, money
from pmm.validation import ValidationError

BASE = Path(__file__).resolve().parent
DATA = BASE / "data" / "transactions.json"
EXPORTS = BASE / "exports"

st.set_page_config(page_title="Pocket Money Manager", page_icon="💰", layout="wide")

st.markdown("""
<style>
.block-container {padding-top: 1.6rem; max-width: 1200px;}
.hero {background: linear-gradient(120deg,#4f46e5,#7c3aed 55%,#db2777); color:#fff;
       padding: 1.3rem 1.6rem; border-radius: 18px; margin-bottom: 1.1rem;}
.hero h1 {margin:0; font-size:1.7rem; color:#fff;} .hero p {margin:.2rem 0 0; opacity:.9;}
div[data-testid="stMetric"] {background: rgba(127,127,127,.08); border:1px solid rgba(127,127,127,.18);
       padding: .9rem 1rem; border-radius: 14px;}
.badge {display:inline-block; padding:.25rem .8rem; border-radius:999px; font-weight:600; color:#fff;}
.badge.Healthy{background:#10b981;} .badge.Caution{background:#f59e0b;} .badge.Critical{background:#ef4444;}
</style>""", unsafe_allow_html=True)


def get_ledger() -> Ledger:
    if "ledger" not in st.session_state:
        st.session_state.ledger = Ledger(Storage(DATA))
    return st.session_state.ledger


ledger = get_ledger()
cur = ledger.settings["currency"]


def to_df(txs) -> pd.DataFrame:
    return pd.DataFrame([{"ID": t.id, "Date": t.date, "Type": t.type, "Category": t.category,
                          "Amount": t.signed_amount, "Description": t.description} for t in txs])


def flash(kind, msg):
    st.session_state["flash"] = (kind, msg)


def show_flash():
    if "flash" in st.session_state:
        kind, msg = st.session_state.pop("flash")
        getattr(st, kind)(msg)


def render_alerts():
    for a in get_alerts(ledger.transactions, ledger.settings):
        {"critical": st.error, "warning": st.warning, "info": st.info}[a.level](a.message)


# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.markdown("## 💰 Pocket Money")
    page = st.radio("Navigate", ["📊 Dashboard", "➕ Add Transaction", "🧾 Transactions",
                                 "📈 Analytics", "📦 Import / Export", "⚙️ Settings"],
                    label_visibility="collapsed")
    st.divider()
    st.metric("Balance", money(ledger.balance(), cur))
    st.caption(f"{len(ledger.transactions)} transactions · data saved automatically")
    for w in ledger.warnings:
        st.warning(w)

st.markdown('<div class="hero"><h1>Pocket Money Manager</h1>'
            '<p>Track what you receive. Control what you spend.</p></div>', unsafe_allow_html=True)
show_flash()
summary = compute_summary(ledger.transactions, ledger.settings)

# ---------------------------------------------------------------- dashboard
if page.endswith("Dashboard"):
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Balance", money(summary["balance"], cur))
    c2.metric("Total income", money(summary["income"], cur))
    c3.metric("Total expense", money(summary["expense"], cur))
    c4.metric("Avg daily spend", money(summary["avg_daily_spend"], cur))
    st.markdown(f'<span class="badge {summary["status"]}">{summary["status"]}</span> '
                f'&nbsp;{summary["status_reason"]}', unsafe_allow_html=True)
    st.caption(summary["trend"])
    render_alerts()
    if summary["count"]:
        left, right = st.columns(2)
        with left:
            st.subheader("Income vs expense by month")
            m = pd.DataFrame(summary["monthly"]).set_index("month")[["income", "expense"]]
            st.bar_chart(m, color=["#10b981", "#ef4444"])
        with right:
            st.subheader("Spending by category")
            cats = pd.Series(category_totals(ledger.transactions), name="Spent")
            st.bar_chart(cats, color="#7c3aed")
        st.subheader("Recent transactions")
        st.dataframe(to_df(filter_transactions(ledger.transactions)[:8]),
                     hide_index=True)
    else:
        st.info("No data yet - add a transaction or import a CSV.")

# ---------------------------------------------------------------------- add
elif page.endswith("Add Transaction"):
    st.subheader("Log money received or spent")
    tx_type = st.radio("Type", [EXPENSE, INCOME], horizontal=True,
                       format_func=lambda t: "💸 Expense (spent)" if t == EXPENSE else "💵 Income (received)")
    with st.form("add_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        d = c1.date_input("Date", value=date.today(), max_value=date.today())
        amount = c2.number_input(f"Amount ({cur})", min_value=0.0, step=10.0, format="%.2f")
        category = st.selectbox("Category", CATEGORIES[tx_type])
        desc = st.text_input("Description", max_chars=100)
        submitted = st.form_submit_button("Save transaction", type="primary")
    if submitted:
        try:
            if tx_type == EXPENSE and ledger.would_overdraw(amount) and amount > 0:
                st.warning("This is more than your current balance - saved anyway so you can review it.")
            tx = ledger.add(tx_type, d.isoformat(), category, amount, desc)
            flash("success", f"Saved {tx.type} of {money(tx.amount, cur)} [{tx.id}].")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))     # defensive validation shared with the CLI

# ------------------------------------------------------------- transactions
elif page.endswith("Transactions"):
    st.subheader("Search & manage")
    f1, f2, f3, f4 = st.columns([2, 1, 1, 1])
    kw = f1.text_input("Keyword")
    typ = f2.selectbox("Type", ["any", INCOME, EXPENSE])
    all_cats = sorted({c for v in CATEGORIES.values() for c in v})
    cat = f3.selectbox("Category", ["any"] + all_cats)
    sort = f4.selectbox("Sort by", ["date", "amount", "category"])
    g1, g2 = st.columns(2)
    dr = g1.date_input("Date range", value=(), max_value=date.today())
    amt = g2.slider("Amount range", 0.0, 100000.0, (0.0, 100000.0), step=50.0)
    d_from = dr[0].isoformat() if len(dr) > 0 else None
    d_to = dr[1].isoformat() if len(dr) > 1 else None
    res = filter_transactions(ledger.transactions, kw, None if cat == "any" else cat,
                              None if typ == "any" else typ, d_from, d_to,
                              amt[0] or None, None if amt[1] >= 100000 else amt[1], sort)
    st.caption(f"{len(res)} match(es)")
    st.dataframe(to_df(res), hide_index=True, height=380)

    if ledger.transactions:
        with st.expander("✏️ Edit or 🗑️ delete a transaction"):
            labels = {t.id: f"{t.date} · {t.category} · {money(t.amount, cur)} · {t.description}"
                      for t in filter_transactions(ledger.transactions)}
            tid = st.selectbox("Choose", list(labels), format_func=labels.get)
            tx = ledger.get(tid)
            with st.form("edit_form"):
                e1, e2 = st.columns(2)
                n_date = e1.date_input("Date", value=date.fromisoformat(tx.date), max_value=date.today())
                n_amt = e2.number_input("Amount", min_value=0.01, value=float(tx.amount), step=10.0)
                cats = CATEGORIES[tx.type]
                n_cat = st.selectbox("Category", cats, index=cats.index(tx.category) if tx.category in cats else 0)
                n_desc = st.text_input("Description", value=tx.description, max_chars=100)
                b1, b2 = st.columns(2)
                save = b1.form_submit_button("Save changes", type="primary")
                delete = b2.form_submit_button("Delete")
            if save:
                try:
                    ledger.edit(tid, date=n_date.isoformat(), amount=n_amt, category=n_cat, description=n_desc)
                    flash("success", "Transaction updated.")
                    st.rerun()
                except ValidationError as exc:
                    st.error(str(exc))
            if delete:
                ledger.delete(tid)
                flash("success", "Transaction deleted.")
                st.rerun()

# ---------------------------------------------------------------- analytics
elif page.endswith("Analytics"):
    st.subheader("Executive summary")
    if not summary["count"]:
        st.info("No data yet.")
    else:
        a, b, c, d = st.columns(4)
        a.metric("Avg transaction", money(summary["avg_transaction"], cur))
        b.metric("Avg expense", money(summary["avg_expense"], cur))
        c.metric("Avg monthly spend", money(summary["avg_monthly_spend"], cur))
        d.metric("Savings rate", f"{summary['savings_rate']}%")
        be = summary["biggest_expense"]
        if be:
            st.write(f"**Biggest expense:** {money(be.amount, cur)} - {be.description} ({be.date})")
        st.write(f"**Trend:** {summary['trend']}")
        m = pd.DataFrame(monthly_breakdown(ledger.transactions))
        st.dataframe(m, hide_index=True)
        st.line_chart(m.set_index("month")[["income", "expense", "net"]])
        if st.button("Generate Matplotlib chart images"):
            try:
                for p in generate_all(ledger.transactions, EXPORTS, ledger.settings):
                    st.image(str(p))
                    st.download_button(f"Download {p.name}", p.read_bytes(), p.name, "image/png",
                                       key=p.name)
            except ChartUnavailable as exc:
                st.error(str(exc))

# ------------------------------------------------------------ import/export
elif page.endswith("Import / Export"):
    t1, t2 = st.tabs(["⬆️ Bulk import", "⬇️ Export"])
    with t1:
        st.caption("Required columns: date, type, category, amount, description")
        up = st.file_uploader("Upload a CSV", type=["csv"])
        if up and st.button("Import file", type="primary"):
            with tempfile.NamedTemporaryFile("wb", suffix=".csv", delete=False) as tmp:
                tmp.write(up.getvalue())
            try:
                res = import_csv(tmp.name, ledger, error_dir=EXPORTS)
                st.success(f"Imported {res.imported} of {res.total} rows · "
                           f"{res.duplicates} duplicates skipped · {len(res.errors)} rejected")
                if res.errors:
                    st.dataframe(pd.DataFrame([{"Row": n, "Problem": why} for n, why, _ in res.errors]),
                                 hide_index=True)
                if res.log_path:
                    st.download_button("Download error log", res.log_path.read_bytes(), res.log_path.name)
            except ValidationError as exc:
                st.error(str(exc))
            finally:
                Path(tmp.name).unlink(missing_ok=True)
    with t2:
        if not ledger.transactions:
            st.info("Nothing to export yet.")
        else:
            for label, fn, mime in (
                    ("Markdown report", lambda: export_markdown(ledger.transactions, ledger.settings, EXPORTS), "text/markdown"),
                    ("Plain-text audit log", lambda: export_text_audit(ledger.transactions, ledger.settings, EXPORTS), "text/plain"),
                    ("CSV report", lambda: export_csv(ledger.transactions, EXPORTS), "text/csv")):
                p = fn()
                st.download_button(f"⬇️ {label}", p.read_bytes(), p.name, mime, key=p.name)

# ----------------------------------------------------------------- settings
else:
    st.subheader("Settings & thresholds")
    s = ledger.settings
    with st.form("settings"):
        c1, c2 = st.columns(2)
        currency = c1.text_input("Currency symbol", value=s["currency"], max_chars=4)
        low = c2.number_input("Low-balance threshold", min_value=0.0, value=float(s["low_balance"]), step=100.0)
        lim = c1.number_input("Monthly spending limit (0 = off)", min_value=0.0, value=float(s["monthly_limit"]), step=500.0)
        mult = c2.number_input("Anomaly multiplier", min_value=1.0, value=float(s["outlier_multiplier"]), step=0.5)
        st.markdown("**Monthly category budgets** (0 = none)")
        budgets, cols = {}, st.columns(4)
        for i, cat in enumerate(CATEGORIES[EXPENSE]):
            v = cols[i % 4].number_input(cat, min_value=0.0, value=float(s["category_budgets"].get(cat, 0)), step=100.0)
            if v > 0:
                budgets[cat] = v
        if st.form_submit_button("Save settings", type="primary"):
            ledger.update_settings(currency=currency or s["currency"], low_balance=low,
                                   monthly_limit=lim, outlier_multiplier=mult, category_budgets=budgets)
            flash("success", "Settings saved.")
            st.rerun()
