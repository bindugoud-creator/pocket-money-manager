# 💰 Pocket Money Manager

Log pocket money received and spent, see balance summaries, get warnings and export reports.
Built for the **DataSpark Challenge – Project #14**. Pure Python standard library for the core;
Matplotlib for charts; Streamlit (optional) for a modern web GUI. One engine powers both front ends.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt    # matplotlib (+ streamlit for the GUI)

python main.py                     # terminal app
streamlit run app_streamlit.py     # modern GUI (optional)
python -m unittest discover -s tests -v   # 20 tests (pytest also works)
```

Needs Python 3.10+. The app ships **pre-seeded with 45 realistic entries** (`data/transactions.json`),
default currency ₹ (change it in Settings). Reset the demo data any time with
`python data/generate_sample.py`.

Options: `python main.py --data path/to/file.json --exports path/to/folder`

## Feature checklist (from the brief)

| Brief requirement | Where / how |
|---|---|
| **Interactive terminal interface** | `pmm/ui_cli.py` – branded banner, 12-option menu, ANSI colours, guided prompts, `q` cancels any prompt |
| **Defensive input validation** | `pmm/validation.py` – rejects blank / text / negative / zero / absurd amounts, bad / impossible / future dates, unknown types & categories, empty or over-long descriptions; `ask()` loops until valid |
| **Core logic engine** | `pmm/engine.py` – add income/expense, edit, delete, balance, overdraw check |
| **Local persistence (JSON/CSV)** | `pmm/storage.py` – JSON store, atomic writes, schema checks; missing/empty/corrupt file → backed up (`*.corrupt-<time>`) and recreated; bad records skipped with a warning |
| **Query & search** | `pmm/search.py` – keyword, category, type, date range, amount range, sort |
| **Executive summary** | `pmm/summary.py` – totals, averages (transaction / daily / monthly), savings rate, top categories, biggest entries, monthly trend (zero-activity months filled), trend sentence, Healthy / Caution / Critical status |
| **Visual data plotting** | `pmm/charts.py` – balance trend, monthly income vs expense, category donut + bars → PNG in `exports/` |
| *Stretch:* **Multi-format export** | `pmm/export.py` – Markdown report, plain-text audit log (with SHA-256 fingerprint), CSV (formula-injection safe) |
| *Stretch:* **Threshold warnings** | `pmm/alerts.py` – low/negative balance, monthly limit breach (and 80% warning), category budgets, anomalous expenses, possible duplicates, inactivity reminder |
| *Stretch:* **GUI enhancement** | `app_streamlit.py` – Dashboard, Add, Transactions (search/edit/delete), Analytics, Import/Export, Settings |
| *Stretch:* **Bulk CSV import** | `pmm/importer.py` – header validation, row-by-row error log in `exports/import_errors_*.log`, safe re-import (skips rows already stored) |
| Sample data (30-50 rows, CSV + JSON) | `data/sample_transactions.csv/.json` (45 rows: normal, boundary 0.01 / ₹25,000 / today, same-day duplicate, 100-char description, mixed-case categories) + `data/sample_broken.csv` |

## 5-minute demo script (matches the brief)

1. `python main.py` → branded welcome screen, balance, and warnings already visible.
2. **Option 2 (Add expense)** → type `abc` for the date, then `-5`, `0`, `99999999` for the amount, `99` for the category and a blank description. Each is caught with a clear message; then enter valid values.
3. **Option 7 (Summary)** → status, averages, category bars, monthly trend, warnings.
4. **Option 4 (Search)** → keyword `pizza`, or category `Food`.
5. **Option 11 (Import)** → `data/sample_broken.csv` → 3 rows imported, 11 rejected with reasons + log file.
6. **Exit (0)** and relaunch → balance and transactions are exactly as you left them (persistence).
7. **Option 10 → 4** → Markdown, audit log, CSV and three PNG charts appear in `exports/`.
8. *(Optional)* `streamlit run app_streamlit.py` → same data in the dashboard.

## Project layout

```
main.py                CLI entry         app_streamlit.py   GUI entry
pmm/  models · validation · storage · engine · search · summary
      alerts · charts · export · importer · ui_cli
data/ transactions.json (live store) · sample_*.csv/json · generate_sample.py
tests/test_pmm.py      exports/  (generated reports, charts, import logs)
```

## Design notes

- Amounts are stored as positive numbers with a `type`; the sign is derived. Rounded to 2 decimals, range 0.01 – 1,000,000.
- Writes are atomic (temp file + `os.replace`) so a crash can never leave half a file.
- Warnings thresholds are configurable (Settings) and persisted with the data.
- Set `NO_COLOR=1` to disable ANSI colours.
