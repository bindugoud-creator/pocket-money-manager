"""Bulk CSV import with header checks and a row-by-row error log."""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .engine import Ledger
from .validation import ValidationError, validate_record

REQUIRED = ("date", "type", "category", "amount", "description")
MAX_ROWS = 50_000


@dataclass
class ImportResult:
    total: int = 0
    imported: int = 0
    duplicates: int = 0
    errors: list = field(default_factory=list)      # (row_number, reason, raw_row)
    log_path: Path | None = None

    @property
    def skipped(self) -> int:
        return len(self.errors) + self.duplicates


def import_csv(path, ledger: Ledger, error_dir=None, skip_duplicates: bool = True) -> ImportResult:
    """Import valid rows, skip bad ones, and write exports/import_errors_*.log."""
    path = Path(path)
    if not path.is_file():
        raise ValidationError(f"File not found: {path}")
    if path.suffix.lower() != ".csv":
        raise ValidationError("Only .csv files can be imported.")

    result = ImportResult()
    try:
        fh = path.open("r", newline="", encoding="utf-8-sig")
    except OSError as exc:
        raise ValidationError(f"Cannot open file: {exc}") from None
    with fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames:
            raise ValidationError("The CSV file is empty.")
        headers = [h.strip().lower() for h in reader.fieldnames if h]
        missing = [c for c in REQUIRED if c not in headers]
        if missing:
            raise ValidationError(f"Missing required column(s): {', '.join(missing)}. "
                                  f"Expected: {', '.join(REQUIRED)}.")
        # Duplicates are judged against data stored BEFORE this import only, so
        # genuine repeats inside one file (two identical coffees) are kept.
        known = {(t.date, t.type, t.category, t.amount, t.description) for t in ledger.transactions}
        good = []
        for row_no, raw in enumerate(reader, start=2):       # row 1 is the header
            if result.total >= MAX_ROWS:
                result.errors.append((row_no, f"Row limit of {MAX_ROWS} reached; rest ignored.", {}))
                break
            result.total += 1
            row = {(k or "").strip().lower(): (v or "") for k, v in raw.items()}
            if None in raw:
                result.errors.append((row_no, "Too many columns in row.", raw))
                continue
            try:
                tx = validate_record(row)
            except ValidationError as exc:
                result.errors.append((row_no, str(exc), raw))
                continue
            sig = (tx.date, tx.type, tx.category, tx.amount, tx.description)
            if skip_duplicates and sig in known:
                result.duplicates += 1
                continue
            good.append(tx)
    result.imported = ledger.add_many(good)

    if error_dir is not None and (result.errors or result.duplicates):
        error_dir = Path(error_dir)
        error_dir.mkdir(parents=True, exist_ok=True)
        log = error_dir / f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.log"
        lines = [f"Import of {path.name} at {datetime.now():%Y-%m-%d %H:%M:%S}",
                 f"Rows read: {result.total} | imported: {result.imported} | "
                 f"duplicates skipped: {result.duplicates} | rejected: {len(result.errors)}", ""]
        lines += [f"Row {n}: {why}  -> {dict(raw)}" for n, why, raw in result.errors]
        log.write_text("\n".join(lines) + "\n", encoding="utf-8")
        result.log_path = log
    return result
