"""Defensive input validation: pure parsers + a looping prompt wrapper."""
from __future__ import annotations

import math
import re
from datetime import date, datetime
from typing import Callable, Optional

from .models import (ALL_CATEGORIES, CATEGORIES, EXPENSE, INCOME, MAX_AMOUNT,
                     MAX_DESC_LEN, MIN_AMOUNT, MIN_DATE, Transaction, new_id)


class ValidationError(ValueError):
    """Raised when user/file input violates a domain constraint."""


class Cancelled(Exception):
    """Raised when the user aborts an interactive prompt."""


# ------------------------------------------------------------------ parsers
def parse_amount(raw) -> float:
    if raw is None:
        raise ValidationError("Amount cannot be blank.")
    s = str(raw).strip()
    for sym in ("₹", "$", "€", "£"):
        s = s.replace(sym, "")
    s = re.sub(r"^(rs\.?|inr)", "", s.strip(), flags=re.I).replace(",", "").replace(" ", "")
    if not s:
        raise ValidationError("Amount cannot be blank.")
    try:
        value = float(s)
    except ValueError:
        raise ValidationError(f"'{raw}' is not a valid number.") from None
    if math.isnan(value) or math.isinf(value):
        raise ValidationError("Amount must be a real finite number.")
    if value <= 0:
        raise ValidationError("Amount must be greater than zero.")
    value = round(value, 2)
    if value < MIN_AMOUNT:
        raise ValidationError(f"Amount is too small (minimum is {MIN_AMOUNT:.2f}).")
    if value > MAX_AMOUNT:
        raise ValidationError(f"Amount is too large (maximum is {MAX_AMOUNT:,.2f}).")
    return value


_DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d")


def parse_date(raw, today: Optional[date] = None) -> str:
    today = today or date.today()
    s = str(raw or "").strip()
    if not s:
        raise ValidationError("Date cannot be blank (use YYYY-MM-DD).")
    for fmt in _DATE_FORMATS:
        try:
            d = datetime.strptime(s, fmt).date()
            break
        except ValueError:
            continue
    else:
        raise ValidationError(f"'{s}' is not a valid date. Use YYYY-MM-DD.")
    if d > today:
        raise ValidationError("Date cannot be in the future.")
    if d < MIN_DATE:
        raise ValidationError(f"Date cannot be before {MIN_DATE.isoformat()}.")
    return d.isoformat()


def parse_type(raw) -> str:
    s = str(raw or "").strip().lower()
    if s in ("income", "i", "in", "received", "credit"):
        return INCOME
    if s in ("expense", "e", "ex", "spent", "debit"):
        return EXPENSE
    raise ValidationError(f"Type must be 'income' or 'expense' (got '{raw}').")


def parse_category(raw, tx_type: Optional[str] = None, allow_index: bool = False) -> str:
    """Match case-insensitively. tx_type=None accepts any known category."""
    s = str(raw or "").strip()
    if not s:
        raise ValidationError("Category cannot be blank.")
    allowed = CATEGORIES[tx_type] if tx_type else ALL_CATEGORIES
    if allow_index and s.isdigit():
        i = int(s)
        if 1 <= i <= len(allowed):
            return allowed[i - 1]
        raise ValidationError(f"Pick a number between 1 and {len(allowed)}.")
    for cat in allowed:
        if cat.lower() == s.lower():
            return cat
    raise ValidationError(f"Unknown category '{s}'. Choose from: {', '.join(allowed)}.")


def parse_description(raw) -> str:
    s = re.sub(r"[\x00-\x1f\x7f]", " ", str(raw or ""))
    s = re.sub(r"\s+", " ", s).strip()
    if not s:
        raise ValidationError("Description cannot be blank.")
    if len(s) > MAX_DESC_LEN:
        raise ValidationError(f"Description too long ({len(s)} > {MAX_DESC_LEN} characters).")
    return s


def parse_non_negative(raw, label: str = "Value") -> float:
    try:
        v = float(str(raw).strip().replace(",", ""))
    except ValueError:
        raise ValidationError(f"{label} must be a number.") from None
    if math.isnan(v) or math.isinf(v) or v < 0:
        raise ValidationError(f"{label} must be zero or greater.")
    return round(v, 2)


def optional(parser: Callable) -> Callable:
    """Wrap a parser so blank input -> None (used for optional filters)."""
    def wrapped(raw):
        return None if not str(raw or "").strip() else parser(raw)
    return wrapped


def validate_record(row: dict, today: Optional[date] = None) -> Transaction:
    """Validate a raw dict (CSV row / JSON record / form) into a Transaction."""
    tx_type = parse_type(row.get("type"))
    return Transaction(
        date=parse_date(row.get("date"), today),
        type=tx_type,
        category=parse_category(row.get("category"), tx_type),
        amount=parse_amount(row.get("amount")),
        description=parse_description(row.get("description")),
        id=str(row.get("id") or "").strip() or new_id(),
    )


# ------------------------------------------------------------ prompt wrapper
def ask(prompt: str, parser: Callable, default: Optional[str] = None,
        input_fn: Callable = input, on_error: Callable = print):
    """Loop until `parser` accepts the input. 'q' cancels; blank uses default."""
    while True:
        try:
            raw = input_fn(prompt)
        except EOFError:
            raise Cancelled() from None
        if raw.strip().lower() == "q":
            raise Cancelled()
        if raw.strip() == "" and default is not None:
            raw = default
        try:
            return parser(raw)
        except ValidationError as exc:
            on_error(f"  ✖ {exc}  (type 'q' to cancel)")


def ask_yes_no(prompt: str, input_fn: Callable = input) -> bool:
    while True:
        try:
            raw = input_fn(prompt + " [y/n]: ").strip().lower()
        except EOFError:
            return False
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print("  ✖ Please answer y or n.")
