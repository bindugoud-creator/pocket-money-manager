"""Threshold warning indicators (low balance, limits, anomalies, inactivity)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Iterable, Optional

from .models import EXPENSE, Transaction
from .summary import category_totals, money


@dataclass
class Alert:
    level: str      # "critical" | "warning" | "info"
    message: str


def get_alerts(txs: Iterable[Transaction], settings: dict,
               today: Optional[date] = None) -> list[Alert]:
    txs = list(txs)
    today = today or date.today()
    cur = settings["currency"]
    alerts: list[Alert] = []
    if not txs:
        return [Alert("info", "No transactions yet - add your first entry to get insights.")]

    balance = sum(t.signed_amount for t in txs)
    if balance < 0:
        alerts.append(Alert("critical", f"Negative balance: {money(balance, cur)}."))
    elif balance < settings["low_balance"]:
        alerts.append(Alert("critical", f"Low balance: {money(balance, cur)} is below "
                                        f"{money(settings['low_balance'], cur)}."))

    month = today.strftime("%Y-%m")
    month_txs = [t for t in txs if t.date.startswith(month)]
    spent = sum(t.amount for t in month_txs if t.type == EXPENSE)
    limit = settings["monthly_limit"]
    if limit:
        if spent > limit:
            alerts.append(Alert("critical", f"Monthly limit breached: spent {money(spent, cur)} "
                                            f"of {money(limit, cur)} this month."))
        elif spent >= 0.8 * limit:
            alerts.append(Alert("warning", f"{spent / limit * 100:.0f}% of the monthly limit "
                                           f"used ({money(spent, cur)} / {money(limit, cur)})."))

    for cat, budget in settings["category_budgets"].items():
        used = category_totals(month_txs).get(cat, 0.0)
        if used > budget:
            alerts.append(Alert("warning", f"{cat} budget exceeded this month: "
                                           f"{money(used, cur)} / {money(budget, cur)}."))

    expenses = [t for t in txs if t.type == EXPENSE]
    if len(expenses) >= 5:
        for t in expenses:
            others = [e.amount for e in expenses if e is not t]
            avg = sum(others) / len(others)
            if avg > 0 and t.amount > settings["outlier_multiplier"] * avg:
                alerts.append(Alert("warning",
                    f"Unusual expense on {t.date}: {money(t.amount, cur)} for '{t.description}' "
                    f"({t.amount / avg:.1f}x your average)."))

    seen = {}
    for t in txs:
        seen.setdefault((t.date, t.type, t.category, t.amount), []).append(t)
    for (d, _, cat, amt), group in seen.items():
        if len(group) > 1:
            alerts.append(Alert("info", f"Possible duplicate: {len(group)} identical "
                                        f"{cat} entries of {money(amt, cur)} on {d}."))

    last = datetime.strptime(max(t.date for t in txs), "%Y-%m-%d").date()
    idle = (today - last).days
    if idle >= settings["inactivity_days"]:
        alerts.append(Alert("info", f"No entries for {idle} days - remember to log recent "
                                    "spending."))
    order = {"critical": 0, "warning": 1, "info": 2}
    return sorted(alerts, key=lambda a: order[a.level])
